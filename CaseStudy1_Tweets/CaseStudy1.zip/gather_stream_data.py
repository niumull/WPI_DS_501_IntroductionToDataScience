# python modules
import sys
import datetime
import time
import twitter
import json
from collections import Counter
import pymongo

#---------------------------------------------
# Define a Function to Login Twitter API
def oauth_login():
    # Go to http://twitter.com/apps/new to create an app and get values
    # for these credentials that you'll need to provide in place of these
    # empty string values that are defined as placeholders.
    # See https://dev.twitter.com/docs/auth/oauth for more information
    # on Twitter's OAuth implementation.

    CONSUMER_KEY = 'YBicfvPPR7YmsJdFtd8qGATmI'
    CONSUMER_SECRET ='YYXKSBw5n6b5dpbwmMfZTjqJcUnDQm6fxlNUEnf63k5idJsj2m'
    OAUTH_TOKEN = '774076984561430528-1ENguVW2E40PSue6YWnDuCBUyASjhGB'
    OAUTH_TOKEN_SECRET = 'ZcjrXboPxPmGEXzq2n1GQN1s7u8ZAXQeKWDSVIrZxQMkV'

    auth = twitter.oauth.OAuth(OAUTH_TOKEN, OAUTH_TOKEN_SECRET,
                               CONSUMER_KEY, CONSUMER_SECRET)

    twitter_api = twitter.Twitter(auth=auth)
    return twitter_api

# save data to mongo database
def save_stream_to_mongo( data, mongo_db, mongo_db_coll, mongo_db_uri="localhost:27017"):

    # Connects to the MongoDB server running on
    # localhost:27017 by default
    client = pymongo.MongoClient(mongo_db_uri)

    # Get a reference to a particular database
    db = client[mongo_db]

    # Reference a particular collection in the database
    coll = db[mongo_db_coll]

    # Perform a bulk insert and return the IDs
    return coll.insert(data)

def save_stream_data(twitter_api, mongo_db_name, mongo_db_coll, mongo_db_uri, q, num_tweets):

    # current_drink = 0

    twitter_stream = twitter.TwitterStream(auth=twitter_api.auth)
    iterator = twitter_stream.statuses.filter(track=q)
    # iterator = twitter_stream.statuses.sample()

    # start_time = time.time()

    # now = datetime.datetime.now().strftime("%H%M")

    print("Drinking from the Twitter firehose...(%s)" % (datetime.datetime.now().strftime("%H:%M:%S")))

    tweet_count = num_tweets

    while True:

        for tweet in iterator:

            save_stream_to_mongo( tweet, mongo_db_name, mongo_db_coll, mongo_db_uri )
            tweet_count -= 1

        if "text" in tweet.keys():
            print(tweet['text'])

        if tweet_count <= 0:
            break

    print("Finished Drinking...(%s)" % (datetime.datetime.now().strftime("%H:%M:%S")))

###############################################################################################
# Begin collecting here
###############################################################################################
# connect to Twitter API
twitter_api = oauth_login()

# MongoDB name and collection
query = "#Patriots"
mongo_db_name = 'ds501_casestudy1'
mongo_db_coll = "pats"
mongo_db_uri = "mongodb://<username>:<password>@ds033046.mlab.com:33046/ds501_casestudy1"

# save streaming data to database
save_stream_data( twitter_api, mongo_db_name, mongo_db_coll, mongo_db_uri, query, 10000 )
